const ENDPOINT = "https://www.stoloto.ru/p/api/mobile/api/v35/service/draws/archive";
const HEADERS = {
  accept: "*/*",
  "content-type": "application/x-www-form-urlencoded",
  "device-platform": "DESKTOP",
  "device-type": "STOLOTO",
  "gosloto-partner": "bXMjXFRXZ3coWXh6R3s1NTdUX3dnWlBMLUxmdg",
  referer: "https://www.stoloto.ru/4x20/archive",
  "user-agent": "Mozilla/5.0 LotoOS/1.0",
};

function normalize(draw) {
  const structured = draw?.combination?.structured;
  if (!Array.isArray(structured) || structured.length !== 8) return null;
  const values = structured.map(Number);
  const fieldA = values.slice(0, 4);
  const fieldB = values.slice(4, 8);
  const valid = [fieldA, fieldB].every(
    (field) => field.length === 4 && new Set(field).size === 4 && field.every((n) => Number.isInteger(n) && n >= 1 && n <= 20),
  );
  if (!valid || draw.status !== "COMPLETED" || draw.completed === false) return null;
  return {
    number: Number(draw.number),
    date: draw.date,
    fieldA,
    fieldB,
    sourceUrl: `https://www.stoloto.ru/4x20/archive/${draw.number}`,
    validationStatus: "verified",
  };
}

async function fetchPage(page, count = 50) {
  const url = new URL(ENDPOINT);
  url.searchParams.set("game", "4x20");
  url.searchParams.set("count", String(count));
  url.searchParams.set("page", String(page));
  const response = await fetch(url, { headers: HEADERS, signal: AbortSignal.timeout(12000) });
  if (!response.ok) throw new Error(`Official source HTTP ${response.status}`);
  const data = await response.json();
  if (data.requestStatus !== "success" || !Array.isArray(data.draws)) throw new Error("Official source schema changed");
  return data.draws;
}

export default async function handler(req, res) {
  try {
    const target = Math.min(1000, Math.max(200, Number(req.query?.limit) || 1000));
    const pages = Math.ceil(target / 50) + 1;
    const all = [];
    for (let page = 1; page <= pages && all.length < target; page++) {
      const rows = await fetchPage(page);
      if (!rows.length) break;
      for (const row of rows) {
        const normalized = normalize(row);
        if (normalized) all.push(normalized);
      }
    }
    const byNumber = new Map(all.map((d) => [d.number, d]));
    const draws = [...byNumber.values()].sort((a, b) => a.number - b.number).slice(-target);
    const gaps = [];
    for (let i = 1; i < draws.length; i++) {
      if (draws[i].number !== draws[i - 1].number + 1) gaps.push([draws[i - 1].number, draws[i].number]);
    }
    if (draws.length < Math.min(200, target)) throw new Error("Недостаточно подтверждённых тиражей");
    res.setHeader("Cache-Control", "s-maxage=300, stale-while-revalidate=3600");
    res.status(200).json({
      source: "official",
      retrievedAt: new Date().toISOString(),
      count: draws.length,
      first: draws[0]?.number ?? null,
      last: draws.at(-1)?.number ?? null,
      quality: { duplicates: 0, gaps, continuous: gaps.length === 0 },
      draws,
    });
  } catch (error) {
    res.status(503).json({
      error: "Не удалось безопасно получить официальный архив",
      detail: error instanceof Error ? error.message : String(error),
    });
  }
}
