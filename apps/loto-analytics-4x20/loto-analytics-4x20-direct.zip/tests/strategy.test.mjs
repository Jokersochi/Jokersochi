import test from "node:test";
import assert from "node:assert/strict";
import { STRATEGIES, DISCLAIMER, generateTicket, generateTickets, maxUsefulTickets } from "../lib/strategy.js";

function history(n=1200){const out=[];for(let i=0;i<n;i++){out.push({number:i+1,fieldA:[1+(i%20),1+((i+3)%20),1+((i+7)%20),1+((i+11)%20)],fieldB:[1+((i*3)%20),1+((i*3+4)%20),1+((i*3+9)%20),1+((i*3+14)%20)]});}return out;}
const draws=history();

test("six strategies have understandable descriptions without promises",()=>{assert.equal(STRATEGIES.length,6);for(const s of STRATEGIES){assert.ok(s.plainDescription.length>60);assert.doesNotMatch(s.plainDescription,/гарант|обязательно выиг|повышает шанс/i);}});
test("every generated ticket has 4+4 valid numbers and matching explanation",()=>{for(const s of STRATEGIES){const t=generateTicket(s.key,draws,42);assert.equal(t.fieldA.length,4);assert.equal(t.fieldB.length,4);assert.deepEqual(t.fieldA,t.explanation.fields[0].numbers);assert.deepEqual(t.fieldB,t.explanation.fields[1].numbers);for(const n of [...t.fieldA,...t.fieldB])assert.ok(n>=1&&n<=20);assert.equal(t.explanation.disclaimer,DISCLAIMER);}});
test("deterministic strategies are limited to one honest ticket",()=>{for(const key of ["hot200","cold200","hot1000","overdue","hybrid"]){assert.equal(maxUsefulTickets(key),1);assert.equal(generateTickets(key,draws,5,1).length,1);}assert.equal(generateTickets("random",draws,5,1).length,5);});
test("explanations contain strategy-specific evidence",()=>{assert.match(generateTicket("hot200",draws,1).explanation.fields[0].details[0],/появлений/);assert.match(generateTicket("cold200",draws,1).explanation.fields[0].details[0],/самых редких/);assert.match(generateTicket("overdue",draws,1).explanation.fields[0].details[0],/средний/);assert.match(generateTicket("hybrid",draws,1).explanation.fields[0].details[0],/общий балл/);assert.match(generateTicket("random",draws,1).explanation.fields[0].summary,/не учитывались/);});
