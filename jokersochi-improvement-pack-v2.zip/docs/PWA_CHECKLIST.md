# PWA чек-лист
- [ ] Манифест корректный и подключен.
- [ ] Service Worker: versioned cache, offline fallback, `skipWaiting()` и `clients.claim()`.
- [ ] Иконки 192/512 PNG, маска для iOS (`apple-touch-icon`).
- [ ] HTTPS в проде, `vite preview` на localhost для тестов.
- [ ] Lighthouse PWA score 100 или близко.
